


var currentValue = 0;
function handleClick(myRadio) {
    // alert('Old value: ' + currentValue);
    // alert('New value: ' + myRadio.value);
    // currentValue = myRadio.value;
    header("Location: index.php");
}